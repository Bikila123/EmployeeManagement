<?php
// database connection
$conn = mysqli_connect('localhost','root','','books') or die('connection failed');
?>