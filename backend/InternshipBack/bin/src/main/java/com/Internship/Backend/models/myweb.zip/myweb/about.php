<?php
include 'config.php';
session_start();

$user_id=$_SESSION['user_id'];

if(!isset($user_id)){
  header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Page</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />

  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="home.css">

</head>
<body>
  
<!-- <section class="about_cont">
    <div class="about_descript"> -->

<?php 
include 'user_header.php';
?>
<section class="about_cont" id="profile">
<div class="about_descript">
      <h1>OUR TEAMS</h1>
      <h3>We are a bookstore website developers. our team has nice coperative work. More over,our location is BENSA DAYE cumpus.
        if you have any questions, sugestions, with regarding to our website, you can communnicate/contact our team members via email whenever.
        <p>Thank you for visting us</p>
      </h3>
    <div class="merge_privat_photos1">
    <div id="tame" class="private_img">
        <img src="./profile_photo/tame.jpg" alt="">
      <a href="home.php" class="book_logo"><p>Tamiru Semeneh</p>
      <p><i class="fas fa-envelope"></i> tamiru@gmail.com</p></a>
      </div>
      <div class="private_img">
        <img src="./profile_photo/tame.jpg" alt="">
      <a href="home.php" class="book_logo"><p>Tamiru Semeneh</p>
      <p><i class="fas fa-envelope"></i> tamiru@gmail.com</p></a>
      </div>
</div>
<div class="merge_privat_photo2">
      <div id="yab" class="private_img">
        <img src="./profile_photo/yeab.jpg" alt="">
      <a href="home.php" class="book_logo"><p>Yeabsira teshome</p>
      <p><i class="fas fa-envelope"></i> yeabsira@gmail.com</p></a>
      
      </div>
      <div class="private_img">
        <img src="./profile_photo/tame.jpg" alt="">
      <a href="home.php" class="book_logo"><p>Wendimagegn abera</p>
      <p><i class="fas fa-envelope"></i> wende@gmail.com</p></a>

      </div>
  </div>
</div>

  </section>

  <section class="questions_cont">
    <div class="questions">
    <h2>Have Any Queries?</h2>
    <p>we value your satisfaction and strive to provide exceptional customer service. If you have any questions, concerns, or inquiries, our dedicated team is here to assist you every step of the way.</p>
    <button class="product_btn" onclick="window.location.href='admin@gmail.com'">Email Us</button>
    </div>
    
  </section>

<?php
include 'footer.php';
?>
<script src="https://kit.fontawesome.com/eedbcd0c96.js" crossorigin="anonymous"></script>

<script src="script.js"></script>

</body>
</html>